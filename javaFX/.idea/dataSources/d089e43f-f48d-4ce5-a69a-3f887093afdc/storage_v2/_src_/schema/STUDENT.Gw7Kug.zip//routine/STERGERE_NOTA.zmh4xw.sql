create PROCEDURE stergere_nota(p_id_utilizator IN varchar2, p_id_film IN varchar2, p_rezultat OUT varchar2)
as
BEGIN
  delete from notee where id_utilizator=p_id_utilizator and id_film=p_id_film;
  p_rezultat := 'Succes: Nota a fost stearsa.';
END;
/

