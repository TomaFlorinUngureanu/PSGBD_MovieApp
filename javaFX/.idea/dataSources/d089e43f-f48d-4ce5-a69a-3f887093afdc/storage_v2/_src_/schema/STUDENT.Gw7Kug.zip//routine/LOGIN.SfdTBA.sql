create PROCEDURE login(p_email IN varchar2,p_parola IN varchar2, p_rezultat OUT varchar2)
AS
   parola_gresita EXCEPTION;
   v_parola varchar2(30) := '';
   v_id varchar2(30) :='';
   v_test integer;
BEGIN
    select count(*) into v_test from emails where email=p_email;
    if(v_test=0)
    then
    p_rezultat := 'Utilizatorul nu exista.';
    else
        select parola into v_parola from utilizatori natural join emails where email=p_email;
       if(v_parola=p_parola)
      then
      select id into v_id from emails where email=p_email;
      p_rezultat := 'Logare cu succes.';
      else
      raise parola_gresita;
      end if;
    end if;
EXCEPTION
WHEN parola_gresita
THEN
raise_application_error(-20001, 'Parola gresita!');
END;
/

