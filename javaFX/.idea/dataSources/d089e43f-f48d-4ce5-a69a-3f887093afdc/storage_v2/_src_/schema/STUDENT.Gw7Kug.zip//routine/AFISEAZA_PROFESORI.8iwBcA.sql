create procedure afiseaza_profesori(camp IN varchar2) as
   v_cursor_id INTEGER;
   v_ok INTEGER;

   v_id_prof int;
   v_nume_prof varchar2(15);
   v_prenume_prof varchar2(30);
begin
  v_cursor_id := DBMS_SQL.OPEN_CURSOR;
  DBMS_SQL.PARSE(v_cursor_id, 'SELECT id, nume, prenume FROM profesori ORDER BY '||camp, DBMS_SQL.NATIVE);
  DBMS_SQL.DEFINE_COLUMN(v_cursor_id, 1, v_id_prof); 
  DBMS_SQL.DEFINE_COLUMN(v_cursor_id, 2, v_nume_prof,15); 
  DBMS_SQL.DEFINE_COLUMN(v_cursor_id, 3, v_prenume_prof,30);   
  v_ok := DBMS_SQL.EXECUTE(v_cursor_id);

  LOOP 
     IF DBMS_SQL.FETCH_ROWS(v_cursor_id)>0 THEN 
         DBMS_SQL.COLUMN_VALUE(v_cursor_id, 1, v_id_prof); 
         DBMS_SQL.COLUMN_VALUE(v_cursor_id, 2, v_nume_prof); 
         DBMS_SQL.COLUMN_VALUE(v_cursor_id, 3, v_prenume_prof); 

         DBMS_OUTPUT.PUT_LINE(v_id_prof || '   ' || v_nume_prof || '    ' || v_prenume_prof);
      ELSE 
        EXIT; 
      END IF; 
  END LOOP;   
  DBMS_SQL.CLOSE_CURSOR(v_cursor_id);
end;
/

