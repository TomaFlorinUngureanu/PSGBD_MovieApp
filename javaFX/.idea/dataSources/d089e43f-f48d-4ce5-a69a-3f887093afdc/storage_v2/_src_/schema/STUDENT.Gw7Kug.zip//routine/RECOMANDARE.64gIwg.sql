create FUNCTION recomandare (p_id_utilizator varchar2)
RETURN VARCHAR2 as
TYPE vector IS TABLE OF PLS_INTEGER INDEX BY VARCHAR2(7);
    scor vector;
    p_imax1 pls_integer := 0;
    p_idmax1 int;
    p_imax2 pls_integer := 0;
    p_idmax2 int;
    p_imax3 pls_integer := 0;
    p_idmax3 int;
    p_imax4 pls_integer := 0;
    p_idmax4 int;
    p_imax5 pls_integer := 0;
    p_idmax5 int;
    p_test int :=1;
    l_idx    varchar2(7);
    p_id number(30,0);
    p_val1 int;
    p_val2 int;
    v_lista varchar2(32667) := '';
    v_genuri varchar2(100) := '';
BEGIN
  FOR v_std_linie IN  (select n2.id_utilizator as id2 from notee n1 join notee n2 on n1.id_film=n2.id_film where n1.id_utilizator=p_id_utilizator and n2.id_utilizator<>p_id_utilizator order by n2.id_utilizator) LOOP  
    scor(v_std_linie.id2) := 0;
  END LOOP;  
  FOR v_std_linie IN  (select n2.id_utilizator as id2, n1.valoare as val1, n2.valoare as val2 from notee n1 join notee n2 on n1.id_film=n2.id_film where n1.id_utilizator=p_id_utilizator and n2.id_utilizator<>p_id_utilizator order by n2.id_utilizator) LOOP  
    p_id := v_std_linie.id2;
    p_val1 := v_std_linie.val1;
    p_val2 := v_std_linie.val2;
    IF (p_val1 = p_val2)
    THEN
      IF (p_val1=10 or p_val1=9)
      THEN
         scor(p_id) := scor(p_id) +5;
      ELSIF (p_val1=8 or p_val1=7)
      THEN 
         scor(p_id) := scor(p_id) +3;
      ELSE
         scor(p_id) := scor(p_id) +1;
      END IF;
    ELSIF(p_val1 > p_val2)
    THEN
      IF (p_val1 in (8,9,10) and p_val2 in (1,2,3))
      THEN
        scor(p_id) := scor(p_id) -5;
      ELSIF (p_val1 in (8,9,10) and p_val2 in (4,5,6))
      THEN
        scor(p_id) := scor(p_id) -3;
        ELSIF (p_val1 in (8,9,10) and p_val2 in (7))
      THEN
        scor(p_id) := scor(p_id) +1;
        ELSIF (p_val1 in (8,9,10) and p_val2 in (8,9,10))
      THEN
        scor(p_id) := scor(p_id) +3;
         ELSIF (p_val1 in (7,6,5) and p_val2 in (1,2,3))
      THEN
        scor(p_id) := scor(p_id) -1;
         ELSIF (p_val1 in (7,6,5) and p_val2 in (4,5,6,7))
      THEN
        scor(p_id) := scor(p_id) +1;
        ELSIF (p_val1 in (1,2,3,4) and p_val2 in (1,2,3,4))
      THEN
        scor(p_id) := scor(p_id) +1;
      END IF;
    ELSE
    IF (p_val2 in (8,9,10) and p_val1 in (1,2,3))
      THEN
        scor(p_id) := scor(p_id) -5;
      ELSIF (p_val2 in (8,9,10) and p_val1 in (4,5,6))
      THEN
        scor(p_id) := scor(p_id) -3;
        ELSIF (p_val2 in (8,9,10) and p_val1 in (7))
      THEN
        scor(p_id) := scor(p_id) +1;
        ELSIF (p_val2 in (8,9,10) and p_val1 in (8,9,10))
      THEN
        scor(p_id) := scor(p_id) +3;
         ELSIF (p_val2 in (7,6,5) and p_val1 in (1,2,3))
      THEN
        scor(p_id) := scor(p_id) -1;
         ELSIF (p_val2 in (7,6,5) and p_val1 in (4,5,6,7))
      THEN
        scor(p_id) := scor(p_id) +1;
        ELSIF (p_val2 in (1,2,3,4) and p_val1 in (1,2,3,4))
      THEN
        scor(p_id) := scor(p_id) +1;
      END IF;
    END IF;
  END LOOP;  
  l_idx := scor.first;
       while (l_idx is not null)
      loop
      if(scor(l_idx)>p_imax1)
      then
         p_imax1 := scor(l_idx);
         p_idmax1 := l_idx;
      end if;
          l_idx := scor.next(l_idx);
     end loop;
     l_idx := scor.first;
       while (l_idx is not null)
      loop
      if(scor(l_idx)>p_imax2 and p_idmax1<>l_idx)
      then
         p_imax2 := scor(l_idx);
         p_idmax2 := l_idx;
      end if;
          l_idx := scor.next(l_idx);
     end loop;
     l_idx := scor.first;
       while (l_idx is not null)
      loop
      if(scor(l_idx)>p_imax3 and p_idmax1<>l_idx and p_idmax2<>l_idx)
      then
         p_imax3 := scor(l_idx);
         p_idmax3 := l_idx;
      end if;
          l_idx := scor.next(l_idx);
     end loop;
     l_idx := scor.first;
       while (l_idx is not null)
      loop
      if(scor(l_idx)>p_imax4 and p_idmax1<>l_idx and p_idmax2<>l_idx and p_idmax3<>l_idx)
      then
         p_imax4 := scor(l_idx);
         p_idmax4 := l_idx;
      end if;
          l_idx := scor.next(l_idx);
     end loop;
     l_idx := scor.first;
       while (l_idx is not null)
      loop
      if(scor(l_idx)>p_imax5 and p_idmax1<>l_idx and p_idmax2<>l_idx and p_idmax3<>l_idx and p_idmax4<>l_idx)
      then
         p_imax5 := scor(l_idx);
         p_idmax5 := l_idx;
      end if;
          l_idx := scor.next(l_idx);
     end loop;
     DBMS_OUTPUT.PUT_LINE(p_imax1||' '||p_idmax1);
     DBMS_OUTPUT.PUT_LINE(p_imax2||' '||p_idmax2);
     DBMS_OUTPUT.PUT_LINE(p_imax3||' '||p_idmax3);
     DBMS_OUTPUT.PUT_LINE(p_imax4||' '||p_idmax4);
     DBMS_OUTPUT.PUT_LINE(p_imax5||' '||p_idmax5);
     FOR v_std_linie IN  (((select * from (select titlu,durata,limba,profit,data_lansare,buget,pagina,id_film from filme f join notee n on f.id=n.id_film group by f.id,f.buget,f.pagina,f.data_lansare,f.profit,f.durata,f.durata,f.limba,f.titlu,n.id_film order by avg(valoare) desc) where rownum<11) union (select titlu,durata,limba,profit,data_lansare,buget,pagina,id_film from filme f join notee n on f.id=n.id_film where n.id_utilizator=p_idmax5 and valoare >=8) union (select titlu,durata,limba,profit,data_lansare,buget,pagina,id_film from filme f join notee n on f.id=n.id_film where n.id_utilizator=p_idmax4 and valoare >=8) union (select titlu,durata,limba,profit,data_lansare,buget,pagina,id_film from filme f join notee n on f.id=n.id_film where n.id_utilizator=p_idmax3 and valoare >=8) union (select titlu,durata,limba,profit,data_lansare,buget,pagina,id_film from filme f join notee n on f.id=n.id_film where n.id_utilizator=p_idmax2 and valoare >=8) union ((select titlu,durata,limba,profit,data_lansare,buget,pagina,id_film from filme f join notee n on f.id=n.id_film where n.id_utilizator=p_idmax1 and valoare >=8)) minus (select titlu,durata,limba,profit,data_lansare,buget,pagina,id_film from filme f join notee n on f.id=n.id_film where n.id_utilizator=p_id_utilizator))
) LOOP  
        v_genuri :='';
        FOR v_std_linie2 IN (select * from genuri where id_film=v_std_linie.id_film) LOOP
        v_genuri := v_genuri||', '||v_std_linie2.gen;
        END LOOP;
        v_genuri := substr(v_genuri,3,length(v_genuri));
        v_lista := v_lista||'titlu='||v_std_linie.titlu||'^nota='||'^genuri='||v_genuri||'^dataLansare='||v_std_linie.data_lansare||'^buget='||v_std_linie.buget||'^profit='||v_std_linie.profit||'^durata='||v_std_linie.durata||'^limba='||v_std_linie.limba||'^paginaWeb='||v_std_linie.pagina||'@';

    END LOOP;  
    return v_lista;
END;
/

