create PROCEDURE inregistrare(p_nume IN varchar2, p_prenume IN varchar2, p_email IN varchar2, p_parola IN varchar2, p_rezultat OUT varchar2)
AS
   v_rezultat varchar2(1000) := 'Succes: Inregistrare cu succes.';
   v_test integer;
   v_idmax integer;
   v_test_email1 varchar2(30) :='';
   v_test_email2 varchar2(30) :='';
   v_test_email3 varchar2(30) :='';
   v_test_email varchar2(50) :='';
   v_i integer;
BEGIN
 IF(p_nume is null OR p_prenume is null OR p_email is null OR p_parola is null)
 THEN
   p_rezultat := 'Eroare: Unul sau mai multe campuri au fost lasate necompletate.';
 ELSE
     select count(*) into v_test from emails where email=p_email;
     IF(v_test=1)
     THEN
      p_rezultat := 'Eroare: Email-ul este deja folosit de un alt cont.';
     ELSE
         IF(length(p_parola)<=5)
         THEN
          p_rezultat := 'Eroare: Parola este prea scurta.';
         ELSE
                v_test_email := p_email;
                v_i := instr(v_test_email, '@');
                v_test_email1 := substr(v_test_email, 1, v_i - 1);
                v_test_email := substr(v_test_email, v_i + 1);
                v_i := instr(v_test_email, '.');
                v_test_email2 := substr(v_test_email, 1, v_i - 1);
                v_test_email3 := substr(v_test_email, v_i + 1);
             IF(p_email not like '%@%.%' or v_test_email1 is null or v_test_email2 is null or v_test_email3 is null or p_email like '%@%@%' or length(v_test_email3)>3)
             THEN
              p_rezultat := 'Eroare: Email invalid.';
             ELSE
                 select max(id)+1 into v_idmax from emails;
                 insert into utilizatori values(v_idmax,p_nume,p_prenume,p_parola);
                 insert into emails values (v_idmax,p_email);
                 p_rezultat := 'Succes: Inregistrare cu succes.'||v_idmax;
              END IF;
          END IF;
      END IF;
  END IF;
END;
/

