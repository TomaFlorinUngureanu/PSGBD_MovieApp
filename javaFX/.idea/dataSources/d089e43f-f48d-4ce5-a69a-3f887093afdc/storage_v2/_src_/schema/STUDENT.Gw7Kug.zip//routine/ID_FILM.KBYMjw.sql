create PROCEDURE id_film(p_titlu IN varchar2,p_id_film OUT varchar2)
as
BEGIN
  select id into p_id_film from filme where titlu=p_titlu;
END;
/

